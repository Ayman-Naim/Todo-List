//
//  AppDelegate.h
//  TodoList
//
//  Created by ayman on 30/08/2023.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

