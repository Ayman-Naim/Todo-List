//
//  Details_EditViewController.h
//  TodoList
//
//  Created by ayman on 30/08/2023.
//

#import "ViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface Details_EditViewController : ViewController
@property  int index;
@property int From_page;
-(void) Load;
@end

NS_ASSUME_NONNULL_END
