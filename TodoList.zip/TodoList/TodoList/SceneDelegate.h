//
//  SceneDelegate.h
//  TodoList
//
//  Created by ayman on 30/08/2023.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

